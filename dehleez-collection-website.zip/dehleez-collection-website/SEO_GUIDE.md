# Dehleez Collection: SEO Guide

## Folder structure (website-upload)
/ (home) · /shop/ · /shop/<category>/ (pens, wallets, mugs, frames, rings, bracelets, gift-deals) · /shop/<category>/<product>/ ·
/about/ · /contact/ · /blog/ · /blog/<post>/ · 404.html · robots.txt · sitemap.xml · manifest.webmanifest · _headers · _redirects · .htaccess · assets/

## IMPORTANT before launch
1. **Domain**: every canonical/sitemap/schema URL uses the placeholder `https://www.dehleezcollection.com`. Your real domain? Re-run: `python3 build.py --domain https://YOURDOMAIN` or find/replace the placeholder in all files.
2. **Reviews**: About page shows "Reviews coming soon". Add real customer reviews only. Never publish invented reviews.
3. **Wallet + Keychain Deal** has no photo yet; add one and set `img` in content.py.
4. "5000+ customers" on About is written as a mission ("serve 5000+"), keep it that way until it is a real figure.

## On-page SEO (done)
- Unique title (<=60 chars) and meta description (70-160) on every page; one H1 per page; clean heading order.
- About / Contact / Blog / Shop follow the sir's keyword rule: primary keyword 3x, five supporting keywords 2x each (verified by script).
- Descriptive alt text, width/height (no layout shift), WebP + srcset, lazy loading, descriptive file names.
- Breadcrumbs, internal links (home > categories > products > blog and back), FAQ section, WhatsApp CTA everywhere.
## Technical SEO (done)
- Clean folder URLs, canonical, hreflang en-PK, robots meta, 404 (noindex).
- JSON-LD: Organization/OnlineStore, WebSite, FAQPage, BreadcrumbList, CollectionPage/ItemList, Product + Offer (PKR), Blog/BlogPosting, ContactPage, AboutPage.
- Open Graph + Twitter cards with 1200x630 images; favicon, apple-touch icon, web manifest.
- sitemap.xml (with images), robots.txt, HTTPS + caching + security headers (_headers for Netlify, .htaccess for cPanel), old .html URLs redirect to folders.
- Mobile-friendly, no render-blocking JS, no frameworks. Test at pagespeed.web.dev after upload.
## Off-page SEO (you must do these)
1. Google Search Console: add property, verify, submit `/sitemap.xml`. Do the same in Bing Webmaster Tools.
2. Create/verify Google Business Profile (online shop, Pakistan, phone 0308-7602039).
3. Facebook and Instagram bios: add website link; post product photos with link; use the same name, phone and email everywhere.
4. Ask real customers for reviews (Google, Facebook) and WhatsApp feedback screenshots (with permission).
5. Get genuine backlinks: local business directories, gift/wedding bloggers, influencer collaborations. Avoid bought links.
6. Share each blog post on Facebook/Instagram; publish 2-4 new gift guides per month.
## Launch checklist
- [ ] Upload contents of `website-upload` to the root of the hosting (Netlify Drop or cPanel public_html)
- [ ] Replace the domain placeholder · [ ] HTTPS on · [ ] Test WhatsApp buttons on phone
- [ ] Submit sitemap · [ ] Rich Results Test on a product page · [ ] Add real reviews and the missing photo
## Add a product
Edit `content.py` (copy a PRODUCTS block), then run `python3 build.py`. Pages, sitemap and schema update automatically.
