# -*- coding: utf-8 -*-
"""Dehleez Collection static site generator.
Usage: python3 build.py [--domain https://www.yourdomain.com]
Outputs: out/website-upload (production) and out/website-offline-preview."""
import os, re, sys, json, shutil, html, argparse, urllib.parse
from PIL import Image, ImageDraw, ImageFont
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from content import *

ap = argparse.ArgumentParser()
ap.add_argument("--domain", default="https://www.dehleezcollection.com")
ap.add_argument("--out", default="/home/claude/seo/out")
A_ = ap.parse_args()
DOMAIN = A_.domain.rstrip("/")
HERE = os.path.dirname(os.path.abspath(__file__))
UP = "/mnt/user-data/uploads"
TODAY = "2026-10-15"
esc = lambda s: html.escape(str(s), quote=True)
CAT = {c["id"]: c for c in CATEGORIES}
PAGE_CATS = [c for c in CATEGORIES if c.get("page", True)]
PROD = {p["slug"]: p for p in PRODUCTS}

def rs(n): return "Rs. {:,}".format(n)
def wa(msg): return "https://wa.me/%s?text=%s" % (WA_NUMBER, urllib.parse.quote(msg))
def pprice(p):
    if p.get("variants"): return "From " + rs(min(v[1] for v in p["variants"]))
    return rs(p["price"]) if p.get("price") else "Price on request"
def purl(p): return "shop/%s/%s/" % (p["cat"] and CAT[p["cat"]]["slug"], p["slug"])
def curl_(c): return "shop/%s/" % c["slug"]

# ---------------- images ----------------
IMG = {}   # key -> dict(slug, alt, sm=(w,h), lg=(w,h))
def process_images(root):
    d = os.path.join(root, "assets", "img"); os.makedirs(d, exist_ok=True)
    for k, (ts, slug, alt) in IMAGES.items():
        src = "%s/WhatsApp_Image_2026-10-03_at_%s.jpeg" % (UP, ts)
        im = Image.open(src).convert("RGB")
        w, h = im.size
        lg = im if w <= 1000 else im.resize((1000, round(h * 1000 / w)), Image.LANCZOS)
        sw = 420; sm = im.resize((sw, round(h * sw / w)), Image.LANCZOS)
        lg.save(os.path.join(d, slug + "-lg.webp"), "WEBP", quality=82, method=6)
        sm.save(os.path.join(d, slug + "-sm.webp"), "WEBP", quality=80, method=6)
        IMG[k] = dict(slug=slug, alt=alt, sm=sm.size, lg=lg.size)
        # OG 1200x630
        og = Image.new("RGB", (1200, 630), (14, 13, 11))
        s = 630 / h if h * 1200 / w > 630 else None
        t = im.copy(); t.thumbnail((620, 560), Image.LANCZOS)
        og.paste(t, (1200 - t.width - 50, (630 - t.height) // 2))
        dr = ImageDraw.Draw(og)
        ft = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf", 54)
        fs = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf", 26)
        dr.text((60, 210), "Dehleez", fill=(217, 187, 116), font=ft)
        dr.text((60, 275), "Collection", fill=(217, 187, 116), font=ft)
        dr.line((60, 350, 260, 350), fill=(184, 150, 74), width=3)
        dr.text((60, 375), "One place many choices", fill=(246, 239, 224), font=fs)
        dr.text((60, 415), "Personalized products", fill=(236, 226, 203), font=fs)
        dr.text((60, 450), "made for you", fill=(236, 226, 203), font=fs)
        og.save(os.path.join(d, "og-" + slug + ".jpg"), "JPEG", quality=84, optimize=True)
    # default OG
    og = Image.new("RGB", (1200, 630), (14, 13, 11))
    x = 560
    for k in ["a", "c", "h", "j"]:
        t = Image.open("%s/WhatsApp_Image_2026-10-03_at_%s.jpeg" % (UP, IMAGES[k][0])).convert("RGB")
        t = t.resize((150, 150), Image.LANCZOS) if False else t
        t.thumbnail((300, 300));
        sq = Image.new("RGB", (240, 240));
        tt = t.copy();
        w_, h_ = tt.size; m = min(w_, h_)
        tt = tt.crop(((w_ - m) // 2, (h_ - m) // 2, (w_ + m) // 2, (h_ + m) // 2)).resize((240, 240))
        og.paste(tt, (560 + (len([1]) * 0) + ((["a","c","h","j"].index(k)) % 2) * 270, 60 + (["a","c","h","j"].index(k) // 2) * 270))
    dr = ImageDraw.Draw(og)
    ft = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf", 64)
    fs = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf", 28)
    dr.text((60, 190), "Dehleez", fill=(217, 187, 116), font=ft)
    dr.text((60, 265), "Collection", fill=(217, 187, 116), font=ft)
    dr.line((60, 350, 300, 350), fill=(184, 150, 74), width=3)
    dr.text((60, 375), "One place many choices", fill=(246, 239, 224), font=fs)
    dr.text((60, 420), "Personalized products", fill=(236, 226, 203), font=fs)
    dr.text((60, 458), "made for you", fill=(236, 226, 203), font=fs)
    og.save(os.path.join(d, "og-dehleez-collection.jpg"), "JPEG", quality=84, optimize=True)
    # icons
    fb = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf", 300)
    def icon(sz):
        im = Image.new("RGB", (512, 512), (14, 13, 11)); dr = ImageDraw.Draw(im)
        dr.rounded_rectangle((20, 20, 492, 492), radius=90, outline=(184, 150, 74), width=10)
        bb = dr.textbbox((0, 0), "D", font=fb)
        dr.text(((512 - (bb[2] - bb[0])) // 2 - bb[0], (512 - (bb[3] - bb[1])) // 2 - bb[1]), "D", fill=(217, 187, 116), font=fb)
        return im.resize((sz, sz), Image.LANCZOS)
    for n, sz in [("favicon-32.png", 32), ("apple-touch-icon.png", 180), ("icon-192.png", 192), ("icon-512.png", 512)]:
        icon(sz).save(os.path.join(root, n))
    icon(64).save(os.path.join(root, "favicon.ico"), sizes=[(16, 16), (32, 32), (48, 48)])

# ---------------- templating context ----------------
class Ctx: mode = "prod"; depth = 0
C = Ctx()
def U(path):
    """internal page link"""
    if C.mode == "prod": return "/" + path
    return "../" * C.depth + path + "index.html"
def AS(path):
    return ("/" + path) if C.mode == "prod" else "../" * C.depth + path
def ABS(path): return DOMAIN + "/" + path

def img(k, cls="", sizes="(max-width:520px) 90vw,(max-width:900px) 45vw,320px", eager=False, alt=None, w_attr=True):
    i = IMG[k]
    sm = AS("assets/img/%s-sm.webp" % i["slug"]); lg = AS("assets/img/%s-lg.webp" % i["slug"])
    ld = 'fetchpriority="high"' if eager else 'loading="lazy" decoding="async"'
    return '<img src="%s" srcset="%s %dw, %s %dw" sizes="%s" width="%d" height="%d" alt="%s" %s%s>' % (
        lg if eager else sm, sm, i["sm"][0], lg, i["lg"][0], sizes, i["lg"][0], i["lg"][1], esc(alt or i["alt"]), ld,
        (' class="%s"' % cls) if cls else "")

ICO_WA = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12.04 2a9.9 9.9 0 0 0-8.5 14.9L2 22l5.25-1.5A9.9 9.9 0 1 0 12.04 2zm5.8 14.1c-.25.7-1.45 1.35-2 1.4-.5.05-1.1.2-3.7-.8-3.1-1.2-5.1-4.4-5.25-4.6-.15-.2-1.25-1.65-1.25-3.15s.8-2.25 1.1-2.55c.3-.3.6-.35.8-.35h.55c.2 0 .4 0 .6.45.2.5.7 1.7.75 1.8.1.1.1.25 0 .4-.1.2-.15.3-.3.45-.15.2-.3.35-.4.5-.15.15-.3.3-.15.6.15.3.7 1.15 1.5 1.85 1 .9 1.9 1.2 2.2 1.3.3.15.45.1.65-.1.2-.25.75-.85.95-1.15.2-.3.4-.25.65-.15.3.1 1.65.8 1.9.95.3.15.5.2.55.3.1.1.1.6-.15 1.3z"/></svg>'
ICO_FB = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M13.5 22v-8.2h2.8l.5-3.3h-3.3V8.4c0-.95.45-1.7 1.8-1.7h1.6V3.8S15.5 3.5 14.2 3.5c-2.7 0-4.4 1.6-4.4 4.5v2.5H7v3.3h2.8V22h3.7z"/></svg>'
ICO_IG = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7.5 2h9A5.5 5.5 0 0 1 22 7.5v9a5.5 5.5 0 0 1-5.5 5.5h-9A5.5 5.5 0 0 1 2 16.5v-9A5.5 5.5 0 0 1 7.5 2zm0 2A3.5 3.5 0 0 0 4 7.5v9A3.5 3.5 0 0 0 7.5 20h9a3.5 3.5 0 0 0 3.5-3.5v-9A3.5 3.5 0 0 0 16.5 4h-9zM12 7a5 5 0 1 1 0 10 5 5 0 0 1 0-10zm0 2a3 3 0 1 0 0 6 3 3 0 0 0 0-6zm5.3-3.2a1.2 1.2 0 1 1 0 2.4 1.2 1.2 0 0 1 0-2.4z"/></svg>'
ICO_MAIL = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5h18a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zm1.6 2L12 12.6 19.4 7H4.6zM4 17h16V9.2l-8 6-8-6V17z"/></svg>'

def jl(o): return '<script type="application/ld+json">%s</script>' % json.dumps(o, ensure_ascii=False, separators=(",", ":"))
def crumbs(items):
    """items: list of (name, path or None for current)"""
    ld = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
        {"@type": "ListItem", "position": i + 1, "name": n, "item": ABS(p)} for i, (n, p) in enumerate(items)]}
    h = '<nav class="crumbs" aria-label="Breadcrumb"><div class="w"><ol>' + "".join(
        ('<li><a href="%s">%s</a></li>' % (U(p), esc(n))) if i < len(items) - 1 else '<li aria-current="page">%s</li>' % esc(n)
        for i, (n, p) in enumerate(items)) + "</ol></div></nav>"
    return h, ld

NAV = [("Home", "", "home"), ("Shop", "shop/", "shop"), ("About", "about/", "about"), ("Blog", "blog/", "blog"), ("Contact", "contact/", "contact")]

def header(active):
    links = "".join('<a href="%s"%s>%s</a>' % (U(p), ' class="act" aria-current="page"' if k == active else "", n) for n, p, k in NAV)
    return ('<a class="skip" href="#main">Skip to content</a><header><div class="w"><a class="logo" href="%s" aria-label="Dehleez Collection home"><b>Dehleez</b><small>Collection</small></a>'
            '<button id="mb" aria-expanded="false" aria-controls="nav">Menu</button><nav id="nav" aria-label="Main">%s'
            '<a class="btn" href="%s" rel="noopener">Order on WhatsApp</a></nav></div></header>') % (U(""), links, wa(BASE_MSG))

def footer():
    cats = "".join('<a href="%s">%s</a>' % (U(curl_(c)), esc(c["name"])) for c in PAGE_CATS)
    return ('<footer><div class="w"><div class="g"><div><a class="logo" href="%s"><b>Dehleez</b><small>Collection</small></a>'
            '<p>%s<br>%s.</p><div class="soc"><a href="%s" target="_blank" rel="noopener me" aria-label="Dehleez Collection on Facebook">%s</a>'
            '<a href="%s" target="_blank" rel="noopener me" aria-label="Dehleez Collection on Instagram">%s</a>'
            '<a href="%s" target="_blank" rel="noopener" aria-label="Order on WhatsApp">%s</a>'
            '<a href="mailto:%s" aria-label="Email Dehleez Collection">%s</a></div></div>'
            '<div><h4>Shop</h4>%s<a href="%s">All products</a></div>'
            '<div><h4>Company</h4><a href="%s">About us</a><a href="%s">Gift ideas blog</a><a href="%s">Contact</a><a href="%s#faq">FAQ</a></div>'
            '<div><h4>Contact</h4><a href="%s" target="_blank" rel="noopener">WhatsApp %s</a><a href="mailto:%s">%s</a><a href="tel:%s">Call %s</a></div></div>'
            '<div class="cp">&copy; 2026 Dehleez Collection. All rights reserved.</div></div></footer>'
            '<a class="fab" href="%s" target="_blank" rel="noopener" aria-label="Order on WhatsApp">%s</a>') % (
        U(""), esc(CORE), esc(TAGLINE), FACEBOOK, ICO_FB, INSTAGRAM, ICO_IG, wa(BASE_MSG), ICO_WA, EMAIL, ICO_MAIL,
        cats, U("shop/"), U("about/"), U("blog/"), U("contact/"), U(""), wa(BASE_MSG), WA_DISPLAY, EMAIL, EMAIL, TEL, WA_DISPLAY,
        wa(BASE_MSG), ICO_WA)

PAGES = []   # (path, priority, changefreq, [ (img_url,title) ])

def page(path, title, desc, body, active, schema, og_slug="dehleez-collection", og_type="website", noindex=False,
         preload=None, imgs=None, modified=TODAY):
    canon = ABS(path)
    ogimg = ABS("assets/img/og-%s.jpg" % og_slug)
    head = ['<meta charset="utf-8">',
            '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">',
            "<title>%s</title>" % esc(title),
            '<meta name="description" content="%s">' % esc(desc),
            '<meta name="robots" content="%s">' % ("noindex, nofollow" if noindex else "index, follow, max-image-preview:large, max-snippet:-1"),
            '<link rel="canonical" href="%s">' % canon]
    if not noindex:
        head += ['<link rel="alternate" hreflang="en-PK" href="%s">' % canon, '<link rel="alternate" hreflang="x-default" href="%s">' % canon]
    head += ['<meta name="theme-color" content="#0e0d0b">', '<meta name="author" content="Dehleez Collection">',
             '<meta property="og:site_name" content="Dehleez Collection">', '<meta property="og:locale" content="en_PK">',
             '<meta property="og:type" content="%s">' % og_type, '<meta property="og:title" content="%s">' % esc(title),
             '<meta property="og:description" content="%s">' % esc(desc), '<meta property="og:url" content="%s">' % canon,
             '<meta property="og:image" content="%s">' % ogimg, '<meta property="og:image:width" content="1200">',
             '<meta property="og:image:height" content="630">', '<meta name="twitter:card" content="summary_large_image">',
             '<meta name="twitter:title" content="%s">' % esc(title), '<meta name="twitter:description" content="%s">' % esc(desc),
             '<meta name="twitter:image" content="%s">' % ogimg,
             '<link rel="icon" href="%s" sizes="any">' % AS("favicon.ico"),
             '<link rel="icon" type="image/png" sizes="32x32" href="%s">' % AS("favicon-32.png"),
             '<link rel="apple-touch-icon" href="%s">' % AS("apple-touch-icon.png"),
             '<link rel="manifest" href="%s">' % AS("manifest.webmanifest"),
             '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>',
             '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Jost:wght@400;500&display=swap">',
             '<link rel="stylesheet" href="%s">' % AS("assets/css/style.css"),
             '<script>document.documentElement.className+=" js"</script>']
    if preload: head.append('<link rel="preload" as="image" href="%s" fetchpriority="high">' % preload)
    for s in schema: head.append(jl(s))
    doc = ('<!DOCTYPE html>\n<html lang="en"><head>%s</head><body>%s<main id="main">%s</main>%s<script src="%s" defer></script></body></html>' % (
        "\n".join(head), header(active), body, footer(), AS("assets/js/main.js")))
    return doc

OUT = {}   # mode -> {path: html}
def emit(path, doc, prio="0.5", freq="monthly", imgs=None, index=True):
    OUT.setdefault(C.mode, {})[path] = doc
    if C.mode == "prod" and index:
        PAGES.append((path, prio, freq, imgs or []))

# ---------------- components ----------------
def card(p):
    c = CAT[p["cat"]]
    media = (img(p["img"], sizes="(max-width:520px) 90vw,(max-width:900px) 45vw,280px") if p.get("img")
             else '<div class="ph">Dehleez<small>Photo coming soon</small></div>')
    badge = '<span class="bd">%s</span>' % esc(p["badge"]) if p.get("badge") else ""
    return ('<article class="card rv" data-name="%s" data-cat="%s"><a class="im" href="%s" tabindex="-1" aria-hidden="true">%s%s</a>'
            '<div class="cd"><span class="ct">%s</span><h3><a href="%s">%s</a></h3><p>%s</p><div class="pr">%s</div>'
            '<div class="mt"><span>Making time: %s</span><span>Customize: %s</span></div>'
            '<div class="rw"><a class="btn d" href="%s">View details</a><a class="btn g" href="%s" target="_blank" rel="noopener">Order on WhatsApp</a></div></div></article>') % (
        esc((p["name"] + " " + c["name"] + " " + p["short"]).lower()), c["id"], U(purl(p)), media, badge, esc(c["name"]),
        U(purl(p)), esc(p["name"]), esc(p["short"]), pprice(p), esc(p["time"]), esc(p["custom"]), U(purl(p)),
        wa("Hi Dehleez Collection, I want to order: %s" % p["name"]))

def ph1(eyebrow, h1, sub, extra=""):
    return '<div class="ph1"><div class="w"><div class="eb">%s</div><h1>%s</h1><p>%s</p>%s</div></div>' % (eyebrow, h1, sub, extra)

def sh(h2, p=None): return '<div class="sh rv"><h2>%s</h2><div class="orn"><i></i></div>%s</div>' % (h2, ("<p>%s</p>" % p) if p else "")

def fin(h2, p, btn_href, btn_txt):
    return ('<section class="fin"><div class="w rv"><h2>%s</h2><p>%s</p><div class="cta c">'
            '<a class="btn" href="%s">%s</a><a class="btn o" href="%s" target="_blank" rel="noopener">Order on WhatsApp</a></div></div></section>') % (
        h2, p, btn_href, btn_txt, wa(BASE_MSG))

def faq_html():
    return "".join("<details><summary>%s</summary><p>%s</p></details>" % (esc(q), esc(a)) for q, a in FAQS)
def faq_ld():
    return {"@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [
        {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in FAQS]}

ORG = lambda: {"@context": "https://schema.org", "@type": ["Organization", "OnlineStore"], "@id": DOMAIN + "/#organization",
    "name": BRAND, "alternateName": "Dehleez", "url": DOMAIN + "/", "slogan": TAGLINE,
    "description": "Dehleez Collection makes customized gifts in Pakistan: personalized mugs, photo frames, wallets, pens, rings, bracelets and gift deals, ordered on WhatsApp.",
    "logo": {"@type": "ImageObject", "url": ABS("icon-512.png"), "width": 512, "height": 512},
    "image": ABS("assets/img/og-dehleez-collection.jpg"), "email": EMAIL, "telephone": TEL,
    "areaServed": {"@type": "Country", "name": "Pakistan"}, "sameAs": [FACEBOOK, INSTAGRAM],
    "contactPoint": {"@type": "ContactPoint", "telephone": TEL, "email": EMAIL, "contactType": "customer service",
                     "areaServed": "PK", "availableLanguage": ["English", "Urdu"]}}
WEBSITE = lambda: {"@context": "https://schema.org", "@type": "WebSite", "@id": DOMAIN + "/#website", "url": DOMAIN + "/",
    "name": BRAND, "inLanguage": "en-PK", "publisher": {"@id": DOMAIN + "/#organization"}}

def itemlist(prods, name):
    return {"@context": "https://schema.org", "@type": "CollectionPage", "name": name, "isPartOf": {"@id": DOMAIN + "/#website"},
            "mainEntity": {"@type": "ItemList", "numberOfItems": len(prods), "itemListElement": [
                {"@type": "ListItem", "position": i + 1, "url": ABS(purl(p)), "name": p["name"]} for i, p in enumerate(prods)]}}

def product_ld(p):
    c = CAT[p["cat"]]
    d = {"@context": "https://schema.org", "@type": "Product", "@id": ABS(purl(p)) + "#product", "name": p["name"],
         "description": p["long"], "sku": p["slug"], "category": c["name"], "brand": {"@type": "Brand", "name": BRAND},
         "url": ABS(purl(p))}
    if p.get("img"):
        d["image"] = [ABS("assets/img/%s-lg.webp" % IMG[p["img"]]["slug"])]
    seller = {"@id": DOMAIN + "/#organization"}
    if p.get("variants"):
        ps = [v[1] for v in p["variants"]]
        d["offers"] = {"@type": "AggregateOffer", "priceCurrency": "PKR", "lowPrice": min(ps), "highPrice": max(ps),
                       "offerCount": len(ps), "availability": "https://schema.org/InStock", "url": ABS(purl(p)), "seller": seller}
    elif p.get("price"):
        d["offers"] = {"@type": "Offer", "priceCurrency": "PKR", "price": p["price"], "availability": "https://schema.org/InStock",
                       "url": ABS(purl(p)), "seller": seller}
    return d

# ---------------- pages ----------------
def build_home():
    C.depth = 0
    hero_imgs = "".join(img(k, eager=False, sizes="(max-width:860px) 45vw,280px") for k in ["a", "c", "f", "i"])
    hero_imgs = hero_imgs.replace('loading="lazy" decoding="async"', 'fetchpriority="high"', 2)
    cats = "".join('<a class="cat rv" href="%s">%s<span>%s<small>%s</small></span></a>' % (
        U(curl_(c)), img(c["img"], sizes="(max-width:520px) 45vw,200px"), esc(c["name"]), esc(c["blurb"])) for c in PAGE_CATS)
    feats = "".join(card(p) for p in PRODUCTS if p.get("feat"))
    why = [("✓", "Made for you", "Add a name, text, photo or design, and your order is prepared around it."),
           ("◷", "Clear price and timing", "Prices and making times are shown on each product. Items still to be confirmed are marked."),
           ("✎", "Spelling confirmed", "We confirm names and details with you before production starts."),
           ("☏", "Easy WhatsApp ordering", "Fill in the details, tap the button and your order opens in WhatsApp.")]
    steps = [("Choose", "Pick a product or a gift deal."), ("Customize", "Add the name, text, size, photos or design idea."),
             ("Confirm", "Send on WhatsApp. We confirm price, timeline and details."), ("We prepare", "Production begins after confirmation, then a quality check before delivery.")]
    body = ('<section class="hero"><div class="w"><div><div class="eb">One place many choices</div>'
            '<h1>Personalized products <em>made for you</em></h1>'
            '<p>Dehleez Collection makes customized gifts in Pakistan: mugs, photo frames, wallets, pens, rings, bracelets and gift deals. Add your name, text or design and order on WhatsApp.</p>'
            '<div class="cta"><a class="btn" href="%s">Shop customized products</a><a class="btn o" href="%s" target="_blank" rel="noopener">Order on WhatsApp</a></div></div>'
            '<div class="mos">%s</div></div></section>'
            '<div class="strip"><div class="w"><div><b>Your name or text</b>on every product</div><div><b>Clear prices</b>shown up front</div>'
            '<div><b>Spelling checked</b>before production</div><div><b>WhatsApp</b>%s</div></div></div>'
            '<section><div class="w">%s<div class="cats">%s</div></div></section>'
            '<section style="padding-top:0"><div class="w">%s<div class="grid">%s</div><p style="margin-top:26px"><a class="btn d" href="%s">See all products</a></p></div></section>'
            '<section class="dk"><div class="w">%s<div class="why">%s</div></div></section>'
            '<section><div class="w">%s<div class="stp">%s</div></div></section>'
            '<section class="dk" style="padding-top:0"><div class="w promo"><div class="rv">%s</div><div class="rv"><div class="eb">Gift Deal</div><h2 style="color:var(--gd2)">A full box, ready to gift</h2><div class="orn"><i></i></div>'
            '<p style="color:var(--cr2)">Bar locket, cap, cotton jersey T-shirt, Aura watch, knot bracelet and alphabet keychain, packed in a deal box. Ready within 7 working days.</p>'
            '<a class="btn" href="%s">View the Gift Deal</a></div></div></section>'
            '<section><div class="w"><div class="wa rv"><div><h2>Order in one message</h2><div class="nb">%s</div><ol><li>Open a product and add your details.</li><li>Tap Order on WhatsApp.</li><li>We confirm and prepare your order.</li></ol></div>'
            '<div><a class="btn g" href="%s" target="_blank" rel="noopener">Chat on WhatsApp</a><p class="note" style="margin-top:16px">Please double-check spelling. We confirm your details before production starts.</p></div></div></div></section>'
            '<section id="faq" style="padding-top:0"><div class="w">%s<div class="rv">%s</div></div></section>'
            '%s') % (
        U("shop/"), wa(BASE_MSG), hero_imgs, WA_DISPLAY,
        sh("Shop by category"), cats,
        sh("Popular customized products", "Photos show sample customizations. Prices and making times are from our product list."), feats, U("shop/"),
        sh("Why choose Dehleez Collection"), "".join('<div class="wy rv"><i>%s</i><h3>%s</h3><p>%s</p></div>' % w for w in why),
        sh("How ordering works"), "".join("<div class=\"rv\"><h3>%s</h3><p>%s</p></div>" % s for s in steps),
        img("i", sizes="(max-width:860px) 90vw,520px"), U(purl(PROD["gift-deal"])), WA_DISPLAY, wa(BASE_MSG),
        sh("Frequently asked questions"), faq_html(),
        fin("Make a gift that feels personal", "Choose a product, add your name or design and send it on WhatsApp.", U("shop/"), "Shop customized products"))
    title = "Dehleez Collection | Customized Gifts in Pakistan"
    desc = "Customized gifts in Pakistan: personalized mugs, photo frames, wallets, pens, rings and gift deals. Add your name or design and order on WhatsApp."
    emit("", page("", title, desc, body, "home", [ORG(), WEBSITE(), faq_ld()],
                  imgs=None), "1.0", "weekly",
         [(ABS("assets/img/%s-lg.webp" % IMG[k]["slug"]), IMAGES[k][2]) for k in ["a", "c", "f", "i"]])

def build_shop():
    C.depth = 1
    chips = "".join('<a class="chip" href="%s">%s</a>' % (U(curl_(c)), esc(c["name"])) for c in PAGE_CATS)
    cats = "".join('<a class="cat rv" href="%s">%s<span>%s<small>%s</small></span></a>' % (
        U(curl_(c)), img(c["img"], sizes="(max-width:520px) 45vw,200px"), esc(c["name"]), esc(c["blurb"])) for c in PAGE_CATS)
    cr, cld = crumbs([("Home", ""), ("Shop", "shop/")])
    body = (ph1("Shop", "Buy Customized Products Online Pakistan", "Every product can carry your name, text or design.") + cr +
            '<section style="padding-bottom:20px"><div class="w"><div class="sh rv" style="margin:0;max-width:70ch"><p style="font-size:18px;color:var(--tx)">Welcome to the easiest way to Buy Customized Products Online Pakistan. Want to buy customized wallet online Pakistan or order personalized photo mug Pakistan? Open the product, add your details and send your order on WhatsApp. Photos show sample customizations.</p></div></div></section>'
            '<section id="categories" style="padding-top:20px"><div class="w">%s<div class="cats">%s</div></div></section>'
            '<section id="shop" style="padding-top:0"><div class="w">%s<div class="tools"><input id="q" type="search" placeholder="Search products" aria-label="Search products"><div class="chips">%s</div></div>'
            '<div class="grid" id="all">%s</div><p id="empty" hidden>No product matches your search. Ask us on WhatsApp and we will tell you what we can prepare.</p></div></section>'
            '<section style="padding-top:0"><div class="w"><div class="wa rv" style="grid-template-columns:1fr"><div><h3 style="font-size:32px">Looking for something else?</h3><p style="color:var(--mu);margin:8px 0 0">Our range is growing. Ask us on WhatsApp about custom name necklace order online, personalized keychain with name order or customized gift hamper online shopping and we will tell you what we can prepare.</p></div></div></div></section>'
            ) % (sh("Shop by category"), cats, sh("All customized products"), chips, "".join(card(p) for p in PRODUCTS))
    body += fin("Ready to Buy Customized Products Online Pakistan?",
                "Whether you want to buy customized wallet online Pakistan or order personalized photo mug Pakistan, we are one message away. You can also ask about a custom name necklace order online, a personalized keychain with name order or a customized gift hamper online shopping request.",
                "#shop", "Browse products")
    title = "Buy Customized Products Online Pakistan | Dehleez"
    desc = "Buy customized products online in Pakistan: mugs, frames, wallets, pens, rings and gift deals from Rs. 600. Add your name and order on WhatsApp."
    emit("shop/", page("shop/", title, desc, body, "shop", [cld, itemlist(PRODUCTS, "Customized products"), ]), "0.9", "weekly",
         [(ABS("assets/img/%s-lg.webp" % IMG[p["img"]]["slug"]), p["name"]) for p in PRODUCTS if p.get("img")][:6])

def build_categories():
    C.depth = 2
    for c in PAGE_CATS:
        ps = [p for p in PRODUCTS if p["cat"] == c["id"]]
        cr, cld = crumbs([("Home", ""), ("Shop", "shop/"), (c["name"], curl_(c))])
        others = "".join('<a class="chip" href="%s">%s</a>' % (U(curl_(o)), esc(o["name"])) for o in PAGE_CATS if o is not c)
        body = (ph1("Shop · " + esc(c["name"]), esc(c["name"]), esc(c["blurb"])) + cr +
                '<section><div class="w"><div class="sh rv" style="max-width:70ch">%s</div><div class="grid">%s</div></div></section>'
                '<section style="padding-top:0"><div class="w"><div class="sh rv"><h2>More categories</h2></div><div class="chips">%s</div></div></section>' % (
                    "".join("<p style=\"font-size:18px;color:var(--tx)\">%s</p>" % esc(x) for x in c["intro"]),
                    "".join(card(p) for p in ps), others) +
                fin("Order your %s" % esc(c["name"].lower()), "Share your details and we will confirm the price, timing and spelling on WhatsApp.", U("shop/"), "See all products"))
        emit(curl_(c), page(curl_(c), c["title"], c["desc"], body, "shop", [cld, itemlist(ps, c["name"])],
                            og_slug=IMG[c["img"]]["slug"]), "0.8", "weekly",
             [(ABS("assets/img/%s-lg.webp" % IMG[p["img"]]["slug"]), p["name"]) for p in ps if p.get("img")])

def field_html(i, f):
    label, typ, req = f
    r = ' data-req="1" required' if req else ""
    lab = esc(label) + ("" if req else " <small>(optional)</small>")
    if typ == "text":
        return '<label>%s<input type="text" data-label="%s"%s autocomplete="off"></label>' % (lab, esc(label), r)
    if typ == "area":
        return '<label>%s<textarea rows="3" data-label="%s"%s></textarea></label>' % (lab, esc(label), r)
    opts = typ.split(":", 1)[1].split("/")
    return '<label>%s<select data-label="%s">%s</select></label>' % (lab, esc(label), "".join("<option>%s</option>" % esc(o) for o in opts))

def build_products():
    C.depth = 3
    for p in PRODUCTS:
        c = CAT[p["cat"]]
        cr, cld = crumbs([("Home", ""), ("Shop", "shop/"), (c["name"], curl_(c)), (p["name"], purl(p))])
        media = (img(p["img"], sizes="(max-width:860px) 92vw,540px", eager=True) if p.get("img")
                 else '<div class="ph" style="padding:60px 20px">Dehleez<small>Photo coming soon</small></div>')
        var = ""
        if p.get("variants"):
            var = '<label>Size <select data-label="Size" data-variant>%s</select></label>' % "".join(
                '<option data-price="%d">%s (%s)</option>' % (v[1], esc(v[0]), rs(v[1])) for v in p["variants"])
        urgent = ('<label class="ckl"><input type="checkbox" data-label="Urgent order" data-add="%d"> Urgent order (+%s)</label>' % (p["urgent"], rs(p["urgent"]))) if p.get("urgent") else ""
        total = ('<div class="note" data-total hidden></div>' if (p.get("price") or p.get("variants")) else "")
        form = ('<form data-wa data-product="%s" data-price="%d" action="https://wa.me/%s" method="get" target="_blank" rel="noopener">'
                '<input type="hidden" name="text" value="%s">%s%s%s'
                '<label>Quantity<input type="number" min="1" value="1" data-label="Quantity" data-qty></label>%s'
                '<div class="er" role="alert"></div><button class="btn g" type="submit">Order on WhatsApp</button>%s</form>') % (
            esc(p["name"]), p.get("price") or 0, WA_NUMBER, esc("Hi Dehleez Collection, I want to order: " + p["name"]),
            var, "".join(field_html(i, f) for i, f in enumerate(p["fields"])), urgent, total,
            '<p class="note">%s</p>' % esc(p.get("note", "Please double-check spelling. We confirm your details before production starts.")))
        spec = "".join("<li>%s</li>" % esc(s) for s in p["spec"])
        rel = [q for q in PRODUCTS if q["slug"] != p["slug"] and q["cat"] == p["cat"]]
        rel += [q for q in PRODUCTS if q["slug"] != p["slug"] and q["cat"] != p["cat"] and q.get("feat")]
        rel = rel[:3]
        body = (cr + '<section id="dt" style="display:block;padding:36px 0 40px"><div class="w dg"><div class="im">%s</div><div>'
                '<span class="tag">%s</span><h1>%s</h1><div class="pr" style="margin:8px 0">%s</div>'
                '<p>%s</p><ul class="sp">%s</ul><p><span class="tag">Making time: %s</span><span class="tag">Customize: %s</span></p>%s</div></div></section>'
                '<section style="padding-top:0"><div class="w">%s<div class="grid">%s</div></div></section>' % (
                    media, esc(c["name"]), esc(p["name"]), pprice(p), esc(p["long"]), spec, esc(p["time"]), esc(p["custom"]), form,
                    sh("You may also like"), "".join(card(q) for q in rel)) +
                fin("Ready to order?", "Send your details on WhatsApp and we will confirm the price, timeline and spelling before production.", U(curl_(c)), "More " + esc(c["name"].lower())))
        og = IMG[p["img"]]["slug"] if p.get("img") else "dehleez-collection"
        pre = AS("assets/img/%s-lg.webp" % IMG[p["img"]]["slug"]) if p.get("img") and C.mode == "prod" else None
        emit(purl(p), page(purl(p), p["title"], p["desc"], body, "shop", [cld, product_ld(p)], og_slug=og, og_type="website", preload=pre),
             "0.7", "monthly", [(ABS("assets/img/%s-lg.webp" % IMG[p["img"]]["slug"]), p["name"])] if p.get("img") else [])

def build_about():
    C.depth = 1
    cr, cld = crumbs([("Home", ""), ("About", "about/")])
    body = (ph1("About Us", "Dehleez Collection: <em>Best Customized Gifts Shop in Pakistan</em>", "One place many choices. Personalized products made for you.") + cr +
            '<section><div class="w two">%s<div class="rv"><div class="eb" style="color:#8a6a1c">Our Story</div><h2 style="font-size:clamp(34px,5vw,50px)">How Dehleez Collection started</h2><div class="orn"><i></i></div>'
            '<p>Dehleez Collection began with a simple idea: people want gifts that feel personal. Instead of searching many different sellers, customers should find personalized products in one place. That idea became our tagline, One place many choices.</p>'
            '<p>Our goal is to become the Best Customized Gifts Shop in Pakistan for anyone who wants a name, a message or a design on something they love. Whether you need a customized name wallet for men, personalized photo mug printing online or a custom name ring with design, you can start your order with one simple WhatsApp message.</p>'
            '<a class="btn d" href="%s">Explore the collection</a></div></div></section>'
            '<section class="dk"><div class="w two" style="grid-template-columns:1fr 1.4fr"><div class="rv"><div class="big">5000+</div><div style="color:var(--gd2);letter-spacing:3px;text-transform:uppercase;font-size:13px">customers to delight</div></div>'
            '<div class="rv"><div class="eb">Our Mission</div><h2 style="font-size:clamp(32px,4.5vw,48px)">Make every gift personal</h2><div class="orn"><i></i></div>'
            '<p style="color:var(--cr2);font-size:17px">Our mission is to serve 5000+ customers with products that carry their own name, message or design. From a premium gift box for birthday celebrations to everyday accessories, we want every order prepared with care and delivered on time. We are building a trusted online gifts store Pakistan can rely on, one carefully checked order at a time.</p></div></div></section>'
            '<section><div class="w"><div class="sh rv" style="margin-bottom:30px"><h2>Why customers trust us</h2><div class="orn"><i></i></div></div><div class="trg">'
            '<div class="wy rv"><i>✓</i><h3>Spelling checked first</h3><p>Every customized name wallet for men and every other order has its spelling, design and size confirmed with you before production starts.</p></div>'
            '<div class="wy rv"><i>◷</i><h3>Clear prices and timing</h3><p>Even personalized photo mug printing online comes with a visible price and making time, so you always know what to expect.</p></div>'
            '<div class="wy rv"><i>☏</i><h3>Direct WhatsApp support</h3><p>Questions about a custom name ring with design? Chat with us directly and get your answers before you order.</p></div></div></div></section>'
            '<section style="padding-top:0"><div class="w"><div class="sh rv" style="margin-bottom:30px"><h2>What customers say</h2><div class="orn"><i></i></div></div>'
            '<div class="wy rv" style="max-width:640px"><h3>Reviews coming soon</h3><p>Ordered from Dehleez Collection? Send your feedback on WhatsApp and it can appear here.</p></div></div></section>'
            ) % (img("g", sizes="(max-width:860px) 92vw,520px", eager=True, alt="Customized name wallet, keychain and pen set in a gift box"), U("shop/"))
    body += fin("Explore the Best Customized Gifts Shop in Pakistan",
                "Find a premium gift box for birthday surprises or a personalized piece just for you, and join our trusted online gifts store Pakistan family today.", U("shop/"), "Shop Customized Products")
    title = "About Dehleez Collection | Customized Gifts Shop"
    desc = "Learn about Dehleez Collection, a customized gifts shop in Pakistan. Our story, our mission and why customers trust us for personalized gifts."
    ld = {"@context": "https://schema.org", "@type": "AboutPage", "name": title, "url": ABS("about/"), "about": {"@id": DOMAIN + "/#organization"}, "inLanguage": "en-PK"}
    emit("about/", page("about/", title, desc, body, "about", [cld, ld], og_slug=IMG["g"]["slug"]), "0.7", "monthly",
         [(ABS("assets/img/%s-lg.webp" % IMG["g"]["slug"]), IMAGES["g"][2])])

def build_contact():
    C.depth = 1
    cr, cld = crumbs([("Home", ""), ("Contact", "contact/")])
    prods = "".join("<option>%s</option>" % esc(n) for n in [p["name"] for p in PRODUCTS] + ["Something else"])
    body = (ph1("Contact Us", "Contact Dehleez Collection For Custom Orders", "One place many choices. Personalized products made for you.") + cr +
            '<section><div class="w cgrid"><div class="rv"><h2 style="font-size:clamp(32px,4.5vw,48px)">Tell us what you would like made</h2><div class="orn"><i></i></div>'
            '<p style="font-size:17px;color:var(--mu)">Ready to Contact Dehleez Collection For Custom Orders? It is easy to order customized gifts on WhatsApp. Share the product, your name or text and your city, and we will confirm the price and timing.</p>'
            '<div class="why" style="grid-template-columns:1fr;gap:14px;margin-top:22px">'
            '<div class="wy"><i>☏</i><h3>WhatsApp Business</h3><p>Looking for a personalized mug printing contact number? Message us on <a href="%s" target="_blank" rel="noopener">%s</a>.</p></div>'
            '<div class="wy"><i>✎</i><h3>Names and details</h3><p>Planning a custom name wallet order Karachi customers can follow? Send the exact spelling and we will confirm it back to you.</p></div>'
            '<div class="wy"><i>✦</i><h3>Friendly help</h3><p>Our online gift shop customer support answers your questions before you order.</p></div>'
            '<div class="wy"><i>❖</i><h3>Delivery</h3><p>Need custom gift delivery all Pakistan wide? Tell us your city and we will confirm the delivery details.</p></div>'
            '<div class="wy"><i>✉</i><h3>Email</h3><p><a href="mailto:%s">%s</a></p></div></div></div>'
            '<form class="rv" data-wa data-product="" action="https://wa.me/%s" method="get" target="_blank" rel="noopener"><h3 style="font-size:30px">Send your order details</h3>'
            '<input type="hidden" name="text" value="%s">'
            '<label>Your name<input type="text" data-label="Name" data-req="1" required></label>'
            '<label>Product<select data-label="Product">%s</select></label>'
            '<label>Name / text / size / city <small>(optional)</small><textarea rows="4" data-label="Details"></textarea></label>'
            '<div class="note">Please double-check spelling. We confirm your details before production starts.</div><div class="er" role="alert"></div>'
            '<button class="btn g" type="submit">Order on WhatsApp</button></form></div></section>') % (
        wa(BASE_MSG), WA_DISPLAY, EMAIL, EMAIL, WA_NUMBER, esc(BASE_MSG), prods)
    body += fin("Contact Dehleez Collection For Custom Orders today",
                "Order customized gifts on WhatsApp, share your name for a custom name wallet order Karachi, ask for the personalized mug printing contact number, reach our online gift shop customer support or check custom gift delivery all Pakistan. We reply on WhatsApp.", U("shop/"), "Shop Customized Products")
    title = "Contact Dehleez Collection | Order on WhatsApp"
    desc = "Contact Dehleez Collection for custom orders. Message 0308-7602039 on WhatsApp or email us with your name, product and city."
    ld = {"@context": "https://schema.org", "@type": "ContactPage", "name": title, "url": ABS("contact/"), "inLanguage": "en-PK",
          "about": {"@id": DOMAIN + "/#organization"}}
    emit("contact/", page("contact/", title, desc, body, "contact", [cld, ld]), "0.7", "monthly")

def build_blog():
    C.depth = 1
    cr, cld = crumbs([("Home", ""), ("Blog", "blog/")])
    cards = ""
    for ps in POSTS:
        rp = PROD[ps["related"][0]]
        cards += ('<article class="card bc rv"><a class="im" href="%s" tabindex="-1" aria-hidden="true">%s</a><div class="cd"><span class="ct">Gift guide</span>'
                  '<h3><a href="%s">%s</a></h3><p>%s</p><a class="lk" href="%s">Read the guide →</a></div></article>') % (
            U("blog/%s/" % ps["slug"]), img(ps["img"], sizes="(max-width:520px) 90vw,320px"), U("blog/%s/" % ps["slug"]),
            esc(ps["title"]), esc(ps["card"]), U("blog/%s/" % ps["slug"]))
    body = (ph1("Gift Ideas Blog", "Best Custom Gift Ideas in Pakistan", "Simple guides to help you choose a gift that feels personal.") + cr +
            '<section><div class="w"><div class="sh rv"><p style="font-size:18px;margin:0;color:var(--tx)">Looking for the Best Custom Gift Ideas in Pakistan? Read our short guides, pick a product you like and add a name, text or design to make it yours.</p></div><div class="grid">%s</div></div></section>' % cards +
            fin("Explore the Best Custom Gift Ideas in Pakistan with Dehleez Collection", "Found something you like? Choose the product, share your customization and send the order on WhatsApp.", U("shop/"), "Shop Customized Products"))
    title = "Custom Gift Ideas in Pakistan | Dehleez Collection Blog"
    desc = "Custom gift ideas for birthdays, anniversaries and weddings in Pakistan. Simple guides with prices, making times and WhatsApp ordering."
    ld = {"@context": "https://schema.org", "@type": "Blog", "name": "Dehleez Collection Gift Ideas Blog", "url": ABS("blog/"), "inLanguage": "en-PK",
          "publisher": {"@id": DOMAIN + "/#organization"},
          "blogPost": [{"@type": "BlogPosting", "headline": x["title"], "url": ABS("blog/%s/" % x["slug"])} for x in POSTS]}
    emit("blog/", page("blog/", title, desc, body, "blog", [cld, ld]), "0.8", "weekly")

    C.depth = 2
    for ps in POSTS:
        path = "blog/%s/" % ps["slug"]
        cr, cld = crumbs([("Home", ""), ("Blog", "blog/"), (ps["title"], path)])
        secs = "".join("<h2>%s</h2><p>%s</p>" % (esc(h), esc(t)) for h, t in ps["sections"])
        rel = "".join(card(PROD[s]) for s in ps["related"])
        body = (cr + '<article><div class="ph1"><div class="w"><div class="eb">Gift guide</div><h1>%s</h1><p>%s</p></div></div>'
                '<section><div class="w art"><div class="im rv">%s</div><div class="rv"><p style="font-size:19px">%s</p>%s</div></div></section></article>'
                '<section style="padding-top:0"><div class="w">%s<div class="grid">%s</div></div></section>' % (
                    esc(ps["title"]), esc(ps["desc"]), img(ps["img"], sizes="(max-width:860px) 92vw,760px", eager=True), esc(ps["intro"]), secs,
                    sh("Products mentioned in this guide"), rel) +
                fin("Ready to order a custom gift?", "Choose the product, share your customization and send the order on WhatsApp.", U("shop/"), "Shop Customized Products"))
        ld = {"@context": "https://schema.org", "@type": "BlogPosting", "headline": ps["title"], "description": ps["desc"],
              "image": [ABS("assets/img/%s-lg.webp" % IMG[ps["img"]]["slug"])], "datePublished": TODAY, "dateModified": TODAY,
              "inLanguage": "en-PK", "mainEntityOfPage": ABS(path),
              "author": {"@type": "Organization", "name": BRAND, "url": DOMAIN + "/"},
              "publisher": {"@id": DOMAIN + "/#organization"}}
        t = ps["title"] + " | Dehleez"
        emit(path, page(path, t if len(t) <= 60 else ps["title"], ps["desc"], body, "blog", [cld, ld], og_slug=IMG[ps["img"]]["slug"], og_type="article"),
             "0.6", "monthly", [(ABS("assets/img/%s-lg.webp" % IMG[ps["img"]]["slug"]), ps["title"])])

def build_404():
    C.depth = 0
    body = ph1("Error 404", "Page not found", "This page may have moved. Try the shop or message us on WhatsApp.",
               '<div class="cta" style="margin-top:22px"><a class="btn" href="%s">Go to shop</a><a class="btn o" href="%s">Home</a></div>' % (U("shop/"), U("")))
    doc = page("404.html", "Page not found | Dehleez Collection", "Page not found.", body, "", [], noindex=True)
    OUT.setdefault(C.mode, {})["404.html"] = doc

# ---------------- static assets ----------------
EXTRA_CSS = """
.js .rv{opacity:0;transform:translateY(22px);transition:opacity .7s,transform .7s}.js .rv.in{opacity:1;transform:none}
[hidden]{display:none!important}
.skip{position:absolute;left:-999px;top:0;background:var(--gd);color:var(--bk);padding:10px 16px;z-index:60}.skip:focus{left:8px;top:8px}
.crumbs{background:var(--cr2);border-bottom:1px solid #d6c79f;font-size:14px}.crumbs ol{list-style:none;display:flex;flex-wrap:wrap;gap:6px;margin:0;padding:10px 0;color:var(--mu)}
.crumbs li+li::before{content:"/";margin-right:6px;color:#b9a77a}.crumbs a{color:#7d6322;text-decoration:none}.crumbs a:hover{text-decoration:underline}
a.chip{text-decoration:none;color:var(--tx);display:inline-block}
.cta.c{justify-content:center}.cgrid{display:grid;grid-template-columns:1fr 1fr;gap:44px;align-items:start}
.lk{color:#7d6322;font-weight:500;text-decoration:none;margin-top:auto}.lk:hover{text-decoration:underline}
.art{max-width:820px}.art .im{border-radius:22px;aspect-ratio:16/10;margin-bottom:28px}.art h2{font-size:clamp(28px,4vw,38px);margin:30px 0 8px}.art p{color:var(--tx);font-size:17px;margin:0 0 8px}
.card h3 a{text-decoration:none}.card h3 a:hover{color:#7d6322}
footer .g{grid-template-columns:1.5fr 1fr 1fr 1.3fr}footer .logo{display:inline-flex}footer p{margin:12px 0 0}
img{height:auto}.mos img{aspect-ratio:1/1}.cta{display:flex;gap:12px;flex-wrap:wrap}.dg .im{aspect-ratio:1/1}.dg .im img{height:100%}
@media(max-width:860px){.cgrid{grid-template-columns:1fr}footer .g{grid-template-columns:1fr 1fr}}
@media(max-width:520px){footer .g{grid-template-columns:1fr}}
"""
JS = r"""(function(){
var d=document;
var mb=d.getElementById('mb'),nav=d.getElementById('nav');
if(mb&&nav){mb.addEventListener('click',function(){var o=nav.classList.toggle('open');mb.setAttribute('aria-expanded',o?'true':'false');});}
var rv=d.querySelectorAll('.rv');
if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target);}});},{threshold:.08});rv.forEach(function(e){io.observe(e);});}
else{rv.forEach(function(e){e.classList.add('in');});}
var q=d.getElementById('q');
if(q){var cards=d.querySelectorAll('#all .card'),em=d.getElementById('empty');
q.addEventListener('input',function(){var t=q.value.trim().toLowerCase(),n=0;cards.forEach(function(c){var ok=!t||c.getAttribute('data-name').indexOf(t)>-1;c.hidden=!ok;if(ok)n++;});if(em)em.hidden=n>0;});}
function fmt(n){return 'Rs. '+String(n).replace(/\B(?=(\d{3})+(?!\d))/g,',');}
d.querySelectorAll('form[data-wa]').forEach(function(f){
 var tot=f.querySelector('[data-total]'),v=f.querySelector('[data-variant]'),u=f.querySelector('[data-add]'),qt=f.querySelector('[data-qty]');
 function price(){var b=parseInt(f.getAttribute('data-price'),10)||0;if(v){b=parseInt(v.options[v.selectedIndex].getAttribute('data-price'),10)||b;}
  if(u&&u.checked)b+=parseInt(u.getAttribute('data-add'),10)||0;var n=Math.max(1,parseInt(qt&&qt.value,10)||1);return {b:b,n:n,t:b*n};}
 function calc(){if(!tot)return;var p=price();if(!p.b){tot.hidden=true;return;}tot.hidden=false;tot.textContent='Estimated price: '+fmt(p.t)+(p.n>1?' ('+p.n+' x '+fmt(p.b)+')':'')+'. Final price is confirmed on WhatsApp.';}
 f.addEventListener('input',calc);calc();
 f.addEventListener('submit',function(e){
  var bad=null,er=f.querySelector('.er');
  f.querySelectorAll('[data-req]').forEach(function(el){if(!bad&&!el.value.trim())bad=el;});
  if(bad){e.preventDefault();if(er)er.textContent='Please fill in: '+bad.getAttribute('data-label');bad.focus();return;}
  if(er)er.textContent='';
  var pr=f.getAttribute('data-product'),L=['Hi Dehleez Collection, I want to order'+(pr?':':' a customized product.')];
  if(pr)L.push('*'+pr+'*');
  f.querySelectorAll('[data-label]').forEach(function(el){
   if(el.type==='checkbox'){if(el.checked)L.push(el.getAttribute('data-label'));return;}
   var val=(el.tagName==='SELECT')?el.options[el.selectedIndex].text:el.value.trim();
   if(val)L.push(el.getAttribute('data-label')+': '+val);});
  var p=price();if(p.b)L.push('Estimated price: '+fmt(p.t));
  L.push('Page: '+location.href.replace(/index\.html$/,''));
  f.querySelector('input[name=text]').value=L.join('\n');
 });
});
})();
"""

def write(root, rel, text):
    p = os.path.join(root, rel); os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    open(p, "w", encoding="utf-8").write(text)

def static_files(root):
    css = open(os.path.join(HERE, "base.css"), encoding="utf-8").read()
    css = css.replace(".rv{opacity:0;transform:translateY(22px);transition:opacity .7s,transform .7s}.rv.in{opacity:1;transform:none}", "")
    css = css.replace("@media(prefers-reduced-motion:reduce){.rv{opacity:1;transform:none;transition:none}", "@media(prefers-reduced-motion:reduce){.js .rv{opacity:1;transform:none;transition:none}")
    assert ".js .rv{opacity:1" in css
    write(root, "assets/css/style.css", css + EXTRA_CSS)
    write(root, "assets/js/main.js", JS)
    write(root, "manifest.webmanifest", json.dumps({
        "name": BRAND, "short_name": "Dehleez", "description": CORE, "start_url": "/", "display": "standalone",
        "background_color": "#0e0d0b", "theme_color": "#0e0d0b", "lang": "en-PK",
        "icons": [{"src": "/icon-192.png", "sizes": "192x192", "type": "image/png"}, {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"}]}, indent=2))

def write_prod_extras(root):
    write(root, "robots.txt", "User-agent: *\nAllow: /\n\nSitemap: %s/sitemap.xml\n" % DOMAIN)
    urls = []
    for path, prio, freq, imgs in PAGES:
        im = "".join("<image:image><image:loc>%s</image:loc><image:title>%s</image:title></image:image>" % (esc(u), esc(t)) for u, t in imgs)
        urls.append("<url><loc>%s</loc><lastmod>%s</lastmod><changefreq>%s</changefreq><priority>%s</priority>%s</url>" % (ABS(path), TODAY, freq, prio, im))
    write(root, "sitemap.xml", '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">\n%s\n</urlset>\n' % "\n".join(urls))
    write(root, "_headers", """/*
  X-Content-Type-Options: nosniff
  X-Frame-Options: SAMEORIGIN
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: camera=(), microphone=(), geolocation=()
/assets/*
  Cache-Control: public, max-age=31536000, immutable
/*.png
  Cache-Control: public, max-age=2592000
/*.ico
  Cache-Control: public, max-age=2592000
""")
    write(root, "_redirects", """# Netlify redirects: old .html style URLs -> clean folder URLs
/index.html  /  301
/shop.html  /shop/  301
/about.html  /about/  301
/contact.html  /contact/  301
/blogs.html  /blog/  301
/blogs  /blog/  301
/blogs/  /blog/  301
/dehleez-collection.html  /  301
""")
    write(root, ".htaccess", """# Apache / cPanel hosting
DirectoryIndex index.html
Options -Indexes
ErrorDocument 404 /404.html

<IfModule mod_rewrite.c>
RewriteEngine On
# Force HTTPS
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}/$1 [R=301,L]
# Old .html URLs -> clean folders
RewriteRule ^shop\\.html$ /shop/ [R=301,L]
RewriteRule ^about\\.html$ /about/ [R=301,L]
RewriteRule ^contact\\.html$ /contact/ [R=301,L]
RewriteRule ^blogs(\\.html)?/?$ /blog/ [R=301,L]
RewriteRule ^index\\.html$ / [R=301,L]
</IfModule>

<IfModule mod_deflate.c>
AddOutputFilterByType DEFLATE text/html text/css application/javascript application/json application/xml image/svg+xml
</IfModule>

<IfModule mod_expires.c>
ExpiresActive On
ExpiresByType image/webp "access plus 1 year"
ExpiresByType image/jpeg "access plus 1 year"
ExpiresByType image/png "access plus 1 month"
ExpiresByType text/css "access plus 1 year"
ExpiresByType application/javascript "access plus 1 year"
ExpiresByType text/html "access plus 0 seconds"
</IfModule>

<IfModule mod_headers.c>
Header set X-Content-Type-Options "nosniff"
Header set X-Frame-Options "SAMEORIGIN"
Header set Referrer-Policy "strict-origin-when-cross-origin"
</IfModule>
""")

def main():
    out = A_.out
    shutil.rmtree(out, ignore_errors=True)
    prod = os.path.join(out, "website-upload"); prev = os.path.join(out, "website-offline-preview")
    for root in (prod, prev):
        os.makedirs(root, exist_ok=True)
        static_files(root)
    process_images(prod)
    shutil.copytree(prod + "/assets/img", prev + "/assets/img")
    for f in os.listdir(prod):
        if f.endswith((".png", ".ico")): shutil.copy(os.path.join(prod, f), os.path.join(prev, f))
    for mode, root in (("prod", prod), ("preview", prev)):
        C.mode = mode
        build_home(); build_shop(); build_categories(); build_products(); build_about(); build_contact(); build_blog(); build_404()
        for path, doc in OUT[mode].items():
            write(root, "404.html" if path == "404.html" else path + "index.html", doc)
    write_prod_extras(prod)
    # preview manifest/icon paths are harmless; note file
    write(prev, "README-OFFLINE-PREVIEW.txt", "Double-click index.html to preview the site on your computer.\nThis folder is ONLY for preview. Upload the 'website-upload' folder to your hosting.\n")
    print("pages:", len(OUT["prod"]), "sitemap urls:", len(PAGES))

main()
