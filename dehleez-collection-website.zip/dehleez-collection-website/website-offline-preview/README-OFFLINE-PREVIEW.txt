Double-click index.html to preview the site on your computer.
This folder is ONLY for preview. Upload the 'website-upload' folder to your hosting.
